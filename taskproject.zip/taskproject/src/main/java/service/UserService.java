package service;

import payload.UserDto;

public interface UserService {
    public UserDto createUser(UserDto userDto);
}
