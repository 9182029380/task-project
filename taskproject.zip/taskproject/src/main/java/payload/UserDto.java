package payload;

import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserDto {
    private long id;
    public String name;
    public String email;
    public String password;


}
